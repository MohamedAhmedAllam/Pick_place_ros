#!/usr/bin/env python

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg

moveit_commander.roscpp_initialize(sys.argv)
rospy.init_node('move_group_controller', anonymous=True)

robot = moveit_commander.RobotCommander()

scene = moveit_commander.PlanningSceneInterface()

group = moveit_commander.MoveGroupCommander("arm")

display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',
                                      moveit_msgs.msg.DisplayTrajectory,
                                      queue_size=20)

print "============ Reference frame: %s" % group.get_planning_frame()

print "============ Reference frame: %s" % group.get_end_effector_link()

print "============ Robot Groups:"
print robot.get_group_names()

print "============ Printing robot state"
print robot.get_current_state()
print "============"

print group.get_end_effector_link()

print group.get_current_pose()


print "============ Generating plan 1"
pose_target = geometry_msgs.msg.Pose()

pose_target = group.get_current_pose()



pose_target.pose.position.x = 0.25   
pose_target.pose.position.y = 0.05 - 0.05
pose_target.pose.position.z = 0.32 + 0.1
#pose_target.orientation.x = 0.04938
#pose_target.orientation.y = -0.557
#pose_target.orientation.z = 0.540
#pose_target.orientation.w = 0.62
#print pose_target
#group.set_start_state_to_current_state()

#pose_target = group.get_random_pose()
#group.set_random_target()
#group.set_position_target([pose_target.position.x, pose_target.position.y,pose_target.position.z])
group.set_pose_target(pose_target)

group.set_goal_position_tolerance(0.01)
group.set_goal_orientation_tolerance(1)
group.set_planner_id('RRTConnectkConfigDefault')
group.set_planning_time(10)
#print group.get_joint_value_target()
print group.get_current_pose()
#group.shift_pose_target(2, -0.1)
#print pose_target

plan1 = group.plan()
group.go(wait=True)
rospy.sleep(10)

print group.get_current_pose()

moveit_commander.roscpp_shutdown()
